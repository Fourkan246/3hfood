<?php $__env->startSection('content'); ?>
    <div class="col-md-1">
    </div>

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-header"> List of all packages</div>
                <div class="card-body">

                    <?php echo $__env->make('admin/layouts/errorMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <table class="table table-hover table-striped table-responsive">
                        <tr>
                            <th>Serial</th>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Price</th>
                            <th>Discount</th>
                            <th>Status</th>
                            <th>Update</th>
                            <th>Action</th>
                        </tr>

                        <?php
                            $i=1
                        ?>
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($package->title); ?></td>
                                <td><?php echo e($package->packageType); ?></td>
                                <td><?php echo e($package->price); ?></td>
                                <td><?php echo e($package->discountPrice); ?></td>
                                <td><?php echo e($package->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.allPackagesList.update', $package->id)); ?>"
                                       class="btn btn-success">Update</a>
                                </td>

                                <td>
                                    <!-- Button trigger modal -->
                                    <a href="#deleteModel<?php echo e($package->id); ?>" class="btn btn-danger" data-toggle="modal">Delete</a>

                                    <!-- Modal -->
                                    <div class="modal fade" id="deleteModel<?php echo e($package->id); ?>" tabindex="-1"
                                         role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModel<?php echo e($package->id); ?>">Attention...!</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">

                                                    This can not be undone!
                                                    Are you sure you want to delete this..?

                                                    <form action="<?php echo route('admin.update.delete', $package->id); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?>

                                                        <button type="submit" class="btn btn-primary">Confirm</button>
                                                    </form>


                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Cancle
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </td>

                            </tr>
                            <?php
                                $i++
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\3hfood\resources\views/admin/packages/listPackages.blade.php */ ?>