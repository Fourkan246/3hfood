<?php $__env->startSection('content'); ?>

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-header"> List of all Members</div>
                <div class="card-body">

                    <?php echo $__env->make('admin/layouts/errorMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <table class="table table-hover table-striped table-responsive">
                        <tr>
                            <th>Serial</th>
                            <th>Name</th>
                            <th>Phone no</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Address</th>
                            <th>Update</th>
                            <th>Delete!</th>
                        </tr>

                        <?php
                            $i=1
                        ?>
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="20px"><?php echo e($i); ?></td>
                                <td width="30px"><?php echo e($member->name); ?></td>
                                <td width="30px"><?php echo e($member->phone_no); ?></td>
                                <td width="30px"><?php echo e($member->email); ?></td>
                                <?php if($member->status == 0): ?> <td>Not Verified</td> <?php endif; ?>
                                <?php if($member->status == 1): ?> <td>Verified</td> <?php endif; ?>
                                <?php if($member->status == 2): ?> <td>General</td> <?php endif; ?>
                                <?php if($member->status == 3): ?> <td>Standard</td> <?php endif; ?>
                                <?php if($member->status == 4): ?> <td>Super</td> <?php endif; ?>
                                <?php if($member->status == 9): ?> <td>Banned</td> <?php endif; ?>

                                <td width="30px"><?php echo e($member->address); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.allMembersList.update', $member->id)); ?>"
                                       class="btn btn-success">Update</a>
                                </td>



                                <td>
                                    <!-- Button trigger modal -->
                                    <a href="#deleteModel<?php echo e($member->id); ?>" class="btn btn-danger" data-toggle="modal">Delete</a>

                                    <!-- Modal -->
                                    <div class="modal fade" id="deleteModel<?php echo e($member->id); ?>" tabindex="-1"
                                         role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="deleteModel<?php echo e($member->id); ?>">Attention...!</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">

                                                    This can not be undone!
                                                    Are you sure you want to delete this..?

                                                    <form action="<?php echo route('admin.member.delete', $member->id); ?>" method="post">
                                                        <?php echo e(csrf_field()); ?>

                                                        <button type="submit" class="btn btn-primary">Confirm</button>
                                                    </form>


                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Cancle
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                </td>


                            </tr>
                            <?php
                                $i++
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\3hfood\resources\views/admin/pages/verifiedMemberList.blade.php */ ?>