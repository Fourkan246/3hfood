<?php $__env->startSection('content'); ?>

    <div class="col-md-4">

        <div class="card card-margin-r">
            <center>
                <img src="<?php echo e(asset('images/lunch_02.jpg')); ?>" class="img-fluid max-width: 100% height: auto" alt="Responsive image">
               
                <div class="card-body">
                    <h6 class="card-title">Fried rice with beaf curry</h6>
                    <p class="card-text">Price 140 BDT (+vat)</p>
                    <a href="#" class="btn btn-primary">Order now!!</a>
                </div>
            </center>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\3hfood\resources\views/admin/pages/index.blade.php */ ?>