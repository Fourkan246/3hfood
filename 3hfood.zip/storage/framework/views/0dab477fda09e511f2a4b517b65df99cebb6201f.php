  

  <?php $__env->startSection('content'); ?>

    <div class="col-md-7 margin-top-70">

      <center>

          <h3>Contact address</h3>
          <h5>Road no: xx holding no: xx</h5>
          <h5>xxxxxx, Cumilla</h5>
          <h5>017xxxxxxxx or 018xxxxxxxx</h5>


          <div class="margin-top-30">

            <h3>For order</h3>
            <h5>call: 017xxxxxxxx</h5>

          </div>

      </center>

    </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\3hfood\resources\views/willcreate.blade.php */ ?>