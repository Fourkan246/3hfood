[<?php echo e($slot); ?>](<?php echo e($url); ?>)

<?php /* C:\xampp\htdocs\3hfood\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php */ ?>