<?php $__env->startSection('content'); ?>

"ene add koirte oibo"

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\3hfood\resources\views/admin/pages/listPackages.blade.php */ ?>