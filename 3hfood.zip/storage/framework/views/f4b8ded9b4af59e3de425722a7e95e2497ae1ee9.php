<?php $__env->startSection('content'); ?>

    <div class="col-md-10">

        <div class="widget">
            <center><h5>Tomorrow's Meals</h5></center>

            <div class="row">

                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-4">
                        <h5>Standard meaal</h5>
                        <div class="card card-margin-r">
                            <center>
                                

                                <?php $i=1; ?>

                                <?php $__currentLoopData = $package->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($i>0): ?>
                                        <img class="card-img-top meal-img" src="<?php echo e(asset('images/packages/'. $image->image)); ?>" alt="Card image">
                                    <?php endif; ?>
                                    <?php $i=0; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="card-body">
                                    <h6 class="card-title"><?php echo e($package->title); ?></h6>
                                    <p class="card-text">Price <?php echo e($package->price); ?> taka only</p>
                                    <?php if( $package->discountPrice > 0 ): ?>
                                        <p class="card-text">Discount <?php echo e($package->discountPrice); ?> taka!!</p>
                                    <?php endif; ?>
                                    <a href="#" class="btn btn-primary">Order now!!</a>
                                </div>
                            </center>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <div class="widget">

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('member.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\3hfood\resources\views/member/pages/index.blade.php */ ?>