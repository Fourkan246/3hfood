<?php echo e($slot); ?>


<?php /* C:\xampp\htdocs\3hfood\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>