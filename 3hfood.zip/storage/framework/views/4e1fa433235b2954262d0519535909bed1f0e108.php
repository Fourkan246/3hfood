<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>3H Food Service</title>

    <link rel="icon" href="/images/capture.png">
    <link rel="stylesheet" href="<?php echo e(asset('css/mainpage/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/mainpage/all.css')); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  </head>
  <body>

      <!-- navigation bar -->

      <?php echo $__env->make('pages.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <!-- end navbar -->



      <!-- Side bar- start -->
      <div class="margin-top-20 margin-left-50">
        <div class="row">

            <div class="col-md-2">
              <div class="list-group">
                <a href="<?php echo e(route('packages')); ?>" class="list-group-item list-group-item-action">Food Packages</a>
                <a href="#" class="list-group-item list-group-item-action">Second item</a>
                <a href="<?php echo e(route('contact')); ?>" class="list-group-item list-group-item-action">Contact</a>
              </div>
            </div>


        <?php echo $__env->yieldContent('content'); ?>


        </div>
      </div>


      <footer class="footer-bottom">
        <p class="text-center">&copy; 2019 All rights reserved </p>
      </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

  </body>
</html>

<?php /* C:\xampp\htdocs\3hfood\resources\views/layouts/master.blade.php */ ?>