<div id="wrapper">
    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">

        <li class="nav-item">
            <a class="nav-link" href="{{ route('willCreate') }}">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Pending Order</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="{{ route('willCreate') }}">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>All Orders</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="{{ route('willCreate') }}">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Catering service</span></a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="{{ route('willCreate') }}">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Our proud customer</span></a>
        </li>

    </ul>
</div>

